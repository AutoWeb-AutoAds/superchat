<?php
ob_start();
include 'EpiTwitter/EpiCurl.php';
include 'EpiTwitter/EpiOAuth.php';
include 'EpiTwitter/EpiTwitter.php';
include 'EpiTwitter/TwitterConfig.php';
$twitterObj = new EpiTwitter($consumer_key, $consumer_secret);
$TwitterLoginUrl=$twitterObj->getAuthorizationUrl();
//echo $TwitterLoginUrl;

header("Location: $TwitterLoginUrl");
//window.open($TwitterLoginUrl);
ob_flush();
?>