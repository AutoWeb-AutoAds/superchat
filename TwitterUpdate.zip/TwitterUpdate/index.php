<?php
session_start();
if(!empty($_SESSION['TwitterUsername']))
{
header('Location: home.php');
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Twitter Status Update - 9lessons.info</title>
</head>
<body>
	<div style="text-align:center">
		<h1>Twitter Status Update using OAuth</h1>
		<a href="http://www.autoads4u.con">WWW.AutoAds4u.com</a><br/><br/><br/>
	
					<br/>	<br/>
		<a href="#" onclick="func_pop()"><img src="EpiTwitter/TwitterButton.png" /></a>
	</div>
	<input type="text" name="textbox1" id="textbox1"/>
 	
<script>
	function func_pop() {
	    var myWindow = window.open("TwitterLogin.php", "", "width=900, height=700");
	}
	function func_console(){
	
		console.log('go my work');
	}
</script>
</body>
</html>