<?php 
include 'EpiTwitter/EpiCurl.php';
include 'EpiTwitter/EpiOAuth.php';
include 'EpiTwitter/EpiTwitter.php';
include 'EpiTwitter/TwitterConfig.php';
include("db.php");
if(isset($_POST['TwitterMessage']) && !empty($_SESSION['TwitterUsername']))
{
$message=mysql_real_escape_string($_POST['TwitterMessage']);
$TwitterUsername=$_SESSION['TwitterUsername'];
$tw_sql=mysqli_query($connection,"SELECT oauth_token,oauth_token_secret FROM TwitterUpdate WHERE uname='$TwitterUsername'");
$row=mysqli_fetch_array($tw_sql,MYSQLI_ASSOC);
$oauth_token=$row["oauth_token"];
$oauth_token_secret=$row["oauth_token_secret"];
if(strlen($oauth_token)>0 && strlen($oauth_token_secret)>0 )
{
$Twitter = new EpiTwitter($consumer_key, $consumer_secret);
$Twitter->setToken($oauth_token,$oauth_token_secret);
$status=$Twitter->post_statusesUpdate(array('status' => $message));
echo $status->id_str;
}
}
?>

