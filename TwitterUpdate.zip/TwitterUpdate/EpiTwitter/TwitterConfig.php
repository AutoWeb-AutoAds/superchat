<?php
$consumer_key = 'X3LaVtEOHRdTBACILxPfGmwDM';
$consumer_secret = '9is1Wwc2pGc1UzT88x6eCgZFtY1GCezKLzNmghnlNRuWhoHhdy';
?>

