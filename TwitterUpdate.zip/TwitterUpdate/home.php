<?php
session_start();
if(empty($_SESSION['TwitterUsername']))
{
header('Location: index.php');
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Twitter Status Update Home - 9lessons.info</title>
	<script  src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script>
	$(document).ready(function(){
	$("#message").keyup(function(){
	var A=$.trim($(this).val());
	$("#count").html(A.length);
	});
		
	$("#submit").click(function(){
	var A=$.trim($("#message").val());
	var dataString = 'TwitterMessage='+ A ;
	if(A.length<=145)
	{
	$.ajax({
	type: "POST",
	url: "TwitterUpdate.php",
	data: dataString,
	cache: false,
	beforeSend: function()
	{
	$("#submit").val("Updating...");
	}, 
	success: function(data)
	{	
	var B=$("#username").val();
    var C='https://twitter.com/'+B+'/status/'+data;
    $("#link").html('<a href="'+C+'" target="_blank">'+C+'</a>');
	$("#submit").val("Post to Twitter");
	$("#message").val("").focus();
	$("#count").html('0');
	}
	});
    }
    else
    {
    alert("Maximum 145 characters.");	
    }

	return false;
	});
		
	});
	</script>
	<style>
    body
    {
	font-family: Arial, 'Helvetica', sans-serif;
    }
	.button-primary {
	background-color: #5fcf80 !important;
	border-color: #3ac162 !important;
	}
	.button {
	z-index: 90;
	font-weight: bold;
	padding: 12px 15px;
	background: #3f8abf;
	color: #fff !important;
	font-size: 14px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	cursor: pointer;
	text-decoration: none;
	text-shadow: 0 1px 0px rgba(0,0,0,0.15);
	border-width: 1px 1px 3px !important;
	border-style: solid;
	border-color: #326e99;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -moz-inline-stack;
	display: inline-block;
	vertical-align: middle;
	zoom: 1;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	-ms-border-radius: 5px;
	-o-border-radius: 5px;
	border-radius: 5px;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	-webkit-box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
	-moz-box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
	box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
	}
	#message{
		width:500px;
		padding:5px;
		font-size:13px;
		height:60px;
		border:1px #333333 solid;
	}
	#count
	{
		font-size:22px;
	    font-family: 'Georgia', sans-serif;
	    color:#cc0000;
	    padding:5px;
	    font-weight:bold;
	}
	#link
	{
	padding:5px;	
	}

	</style>
</head>
<body>
	<div style="margin:auto; width:900px">
	<h1>Welcome to <?php echo $_SESSION['TwitterFullname']; ?></h1>
				
	<form method="post" action="">
	<textarea id="message"></textarea><span id="count">0</span><br/><input type="hidden" value="<?php echo $_SESSION['TwitterUsername']; ?>" id="username"/>
	<input type="submit" id="submit" class="button button-primary" value="Post to Twitter"/> <div id="link"></div>
	</form>
	
	<br/>
	<a href="TwitterLogout.php">Logout</a>
	
	</div>
</body>
</html>