<?php
session_start();
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'twitter');
define('DB_PASSWORD', '12345!@');
define('DB_DATABASE', 'autoadsu_Twitter');
$connection = @mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE) or die(mysqli_error());
?>
